package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IGa_p2_score_outClient{
void score_from_p2_score_out(String action_message_score_txt_var);
}