package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IGa_p1_action{
void rock_via_p1_action();
void paper_via_p1_action();
void scissor_via_p1_action();
}