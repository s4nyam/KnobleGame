package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPlayer_score_in{
void score_via_score_in(String action_message_score_txt_var);
}