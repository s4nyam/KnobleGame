package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPlayer_action_outClient{
void rock_from_action_out();
void paper_from_action_out();
void scissor_from_action_out();
}